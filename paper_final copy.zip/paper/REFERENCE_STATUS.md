# Are the references real? An honest accounting

You asked me to judge this myself. Here is the accounting, including one error
I just found.

## An error found while checking

**Yang et al.** was cited as 2023 with no volume or pages. The published
version is *Electronic Commerce Research* 25(1), 39-67, February 2025; 2023 was
the online-first date. Corrected.

## One entry I cannot confirm

**Zhou et al. (2023), Journal of Ambient Intelligence and Humanized
Computing, 14(8), 9973-9983.** A paper matching the description exists in that
journal (Dempster-Shafer feature ranking from product reviews, DOI
10.1007/s12652-021-03664-1), but I could not confirm the author list, volume or
pages. A LaTeX comment now marks it as unverified.

It supports one background sentence. If Scopus does not confirm it, delete the
citation and the sentence; nothing in the paper depends on it.

## Verification tiers for the remaining 50

**Confirmed directly during preparation (23).** Bibliographic details checked
against a publisher page, PubMed, the ACL Anthology or the ACM Digital Library:
Hou 2026, Maqbool 2023, de Matos 2007, Xia 2021, Mittal 1999, LaBarbera and
Mazursky 1983, Schoenfeld 1983, Killick 2012, Politis and Romano 1992 and 1994,
Suissa 2007 and 2008, Peduzzi 1996, Vittinghoff 2007, Adams and MacKay 2007,
Page 2021, Baumeister 2001, Rozin and Royzman 2001, Jindal and Liu 2008, Ott
2011, Mohawesh 2021, Park and Kim 2024, Roelen-Blasberg 2023.

One of these was itself a correction: the TKDD paper was cited as "Jiang, S.,
et al." The first author is Xia and the Jiang initial was also wrong.

**Seen in the reference lists of retrieved peer-reviewed documents (23).**
Existence is near-certain because other authors cite them, but I did not open
the publisher page, so volume and page numbers should be checked: Kunsch 1989,
Politis and White 2004, Patton 2009, Killick and Eckley 2014, Levesque 2010,
Platt 2019, Karim 2016, Mi 2016, Yadav and Lewis 2021, van Smeden 2016, Barry
and Hartigan 1993, Fearnhead and Liu 2007, Mukherjee 2012, Paul and Nikolaev
2021, Luca 2011, Rosenthal 1979, Easterbrook 1991, Ioannidis 2005, Fanelli
2010, Chambers 2013, Franco 2014, Nosek 2015, Moher 2009, Maalej and Nabil
2015.

**Classics not checked this session (4).** Cox 1972, Kaplan and Meier 1958, Hu
and Liu 2004. These are among the most-cited papers in their fields and I am
confident in the details, but confidence is not verification.

## What this means

No reference in this bibliography was written from memory as a plausible-looking
invention. Every entry began from something I retrieved. Two had errors of
detail, both now fixed or flagged.

That is a different claim from "all 52 are correct". Twenty-seven entries have
page numbers I have not personally confirmed. For a journal submission the
right procedure is to run the bibliography through Scopus or Web of Science and
check each one. That takes an hour and I cannot do it from here.

## What I would check first

1. Zhou et al. Confirm or remove.
2. The 23 second-tier entries, for volume and page numbers.
3. Hou et al. 2026. If the ACL proceedings are not yet published, mark it "to
   appear".
