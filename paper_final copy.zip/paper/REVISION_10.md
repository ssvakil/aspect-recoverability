# Response to the tenth review

## Eight reported critical defects do not exist

Each was checked against the source and the rendered PDF:

| Reported | Actual |
|---|---|
| Table 3 rows shuffled | 50%: 2,291 / 1,589 / 69.4%; 75%: 2,150 / 955 / 44.4%; 90%: 453 / 0 / 0.0%. Matches the run log exactly. |
| Paragraph duplicated in 5.6 | Appears once |
| "5.16 A note on dataset provenance" twice | No run-on in the PDF |
| Headings 6.1-6.3 duplicated | No run-on in the PDF |
| "8 ConclusionWe set out..." | No run-on in the PDF |
| Tables 7 and 9 contain broken HTML | Zero HTML tags in the file |
| Abstract says "five reviews per unit-period" | Abstract says `for $R$ reviews per unit-period` |
| "Tsoros" in the Mittal reference | Reads Tsiros |

The abstract item identifies the cause. A math-mode `$R$` was read as "five".
An extractor that mangles inline maths will also mangle table cells, which
explains the apparently shuffled rows: cell contents were merged across
columns during extraction.

This is the sixth consecutive review to report defects the file does not
contain. Acting on such reports without checking would introduce real errors
into a clean document. **Give the reviewing tool the `.tex` source, not the
PDF.**

## Four legitimate criticisms, all corrected

**Section 5.5's title contradicted Section 5.7.** "Detected shocks are
indistinguishable from noise" was written before PELT was run and is no longer
accurate as a general claim. Retitled "The threshold rule finds no excess over
the null", which is what that section establishes.

**Section 5.3 contradicted itself on the word "marginal".** One paragraph
called a category-level cohort analysis "marginal rather than impossible" and
the next said "marginal overstates what these rates allow". The first is
rewritten; the verdict is now stated once.

**No Kaplan-Meier figure.** We reported that the confidence bands were wide
without showing them, which the review correctly calls an empty claim.
Figure 12 now gives both curves with log-log bands. The bands span roughly 0.3
in survival probability and overlap throughout, which is the reason the
five-fold difference in medians should not be read as a real difference. Nine
consistency checks were added: survival non-increasing, bands bracketing the
estimate, risk set never growing, zero-event months leaving survival unchanged.

**Figure 9 rounded the panel size to "75k".** Now 74,780.

## Also addressed

The abstract described the two measures as disagreeing about outcomes, which
sat oddly with Section 5.13 withdrawing any inference from the divergence. It
now states the difference and says explicitly that no inference is drawn.

## Acknowledged and not fixed

**PELT penalty not tuned.** 3log(n)sigma-squared is a convention we adopted.
Testing alternatives would change the number of tests and tighten Bonferroni
further, which the review also notes. Since the result does not survive
correction at four tests, testing more penalties can only weaken it. We state
the limitation rather than running an analysis whose only possible outcome is
to weaken a result we already decline to rely on.

**phi = 0.6 chosen rather than estimated.** Estimating it from the panel is the
better procedure. The reported power sits mid-range between phi = 0 (0.89) and
phi = 0.85 (0.59), and the false positive rate is 0.93 even at phi = 0, so the
headline finding does not depend on the value. We would rather say this than
estimate one number and imply the synthetic series were matched in every
respect.
