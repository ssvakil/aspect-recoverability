# Response to the eleventh review

Both reviewers now agree the earlier "critical defects" were extraction
artefacts. Thank you for checking. The remaining items are real and this round
addresses them.

## My argument against the PELT penalty test was wrong

I wrote that testing more penalties "only tightens Bonferroni, so it can only
weaken a result we already decline to rely on". That reasoning does not hold.

Multiple comparison correction is required when one selects the most favourable
of several results. It is not required to show a result is stable across a
nuisance parameter. If every penalty gives a similar ratio, that is robustness.
If they diverge, the result depends on a value we never tuned and should not be
relied on. Either reading is informative and neither involves picking a winner.

`pelt_penalty_sensitivity` now runs PELT at multipliers 2, 3, 4 and 6, each
against its own null, and reports ratio and empirical p for each. Four
self-tests: the table covers each multiplier, a larger penalty never finds more
change points, every row carries its own null, and empirical p is never zero.

## phi is now estimated rather than chosen

`estimate_phi` computes the lag-one autocorrelation of the observed series,
pooled, weighted by series length, and per series with its range. This is the
Yule-Walker estimate for an AR(1).

The run prints the gap against the 0.6 we assumed and says outright that the
positive control should be re-run if the gap exceeds 0.15. Four self-tests:
phi recovered near 0.0 and near 0.6 on synthetic AR(1) series, NaN on empty
input, and NaN rather than zero on a constant series.

**Both require one run:**

    python followup_analyses.py --scan 500000 --presence 0.75 --reps 999

## Table 4 caption clarified

The item-level rate appears as 0.059 % in the table and 0.063 % in the text,
for the balanced panel and the 300,000-interaction scan respectively. The
caption now says so and notes the difference is sampling rather than substance.

## Figure 11 caption no longer overgeneralises

"None was significant against the null" was true of the threshold grid and
could be read as covering the change point analysis. The caption now says the
statement applies to the threshold rule only and points to Section 5.7.

## Abstract no longer describes the measures as disagreeing

Section 5.13 withdrew any inference from the star/lexicon divergence; the
abstract still said they "disagree about outcomes". It now says they measure
different things and need not agree.

## Contribution framing, as both reviews asked

A paragraph at the head of the introduction states what is and is not claimed:
not that decline and return does not occur, nor that it is unmeasurable in
principle, but that we establish a pre-analysis feasibility criterion that
decides before collection whether a given design is identifiable on a given
corpus.

## A defence of the 30-mention threshold

Two reviews asked why 30. The paper now gives the reason rather than only the
provenance. It was fixed before data inspection, which answers the worst
objection. Its magnitude follows from the shock criterion: a shock is a
one-standard-deviation departure from a six-month baseline, so the monthly mean
must be stable enough that such a move is not routine sampling noise. At 30
mentions the standard error of a monthly mean is about 0.18 of the series
standard deviation; at 10 it is 0.32, and a baseline standard deviation
estimated from six such months becomes unreliable in its own right. Table 8
gives the bound from T = 5 to 50 for readers who prefer another value.

## Not done: compression to 20 pages

The paper is 27 pages. One review suggests trimming. We would rather not: most
of the length is qualifications, withdrawn inferences and negative controls,
and those are the parts that make the result defensible. If an editor asks, the
candidates are Section 5.12, which could merge into 5.5, and the three
qualification paragraphs in 5.7, which could become one.
